export const BASE_URL = "https://geo.ipify.org/api";
export const API_VERSION = "/v2/country,city";
export const API_KEY = "?apiKey=at_2pbj9odncSriZGyVb1hOCYDUFVSfM";
